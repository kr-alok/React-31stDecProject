
const all = {
    serviceUrl: "https://api.myjson.com/bins/aupji",
}

export default all;